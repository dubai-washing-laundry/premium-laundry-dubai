# Premium Laundry Dubai Website

Files:
- `index.html` — main website
- `style.css` — premium responsive design
- `script.js` — mobile menu and footer year

## Important
Before publishing, replace the placeholder phone number `971500000000` in `index.html` with your real WhatsApp/call number.

The site is designed to work as a static GitHub Pages website.
